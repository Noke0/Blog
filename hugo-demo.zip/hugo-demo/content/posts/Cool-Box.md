---
title: "Cool Box"
date: 2023-06-27T20:49:17+02:00
tags:
  - Penetration Testing
  - Hack The Box
---

## Hello Teee

```javascript
console.log("Test")
```

That is, why we are cool

![PictureText Or is it?](</Squashed-Images/Pasted image 20230626201003.png>)